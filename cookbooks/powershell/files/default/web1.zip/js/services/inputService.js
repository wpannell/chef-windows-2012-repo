'use strict';
(function () {
  var services = angular.module('cytology.inputService', []);
  services.factory('inputService', [
    '$http', '$q', 'keyboardService', 'scanner',
    function ($http, $q, keyboardService, scanner) {
      var handle = '/Input', buffer = '', subscription;

      var inputService = {
        subscribe: function () {
          var defer = $q.defer(), buffer = '';

          keyboardService.subscribe().then(this.set);
          scanner.subscribe().then(this.set);

          subscription = subscribe(handle, function (payload) {
            defer.resolve(payload);
          });
          return defer.promise;
        },

        isSubscribed: function () {
          return subscription !== undefined;
        },

        buffer: function () {
          return buffer;
        },

        set: function (text) {
          buffer = text;
          publish(handle, [text]);
        },

        unsubscribe: function () {
          keyboardService.unsubscribe();
          scanner.unsubscribe();
          unsubscribe(subscription);
          subscription = undefined;
        }
      };
      return inputService;
    }
  ]);
})();
