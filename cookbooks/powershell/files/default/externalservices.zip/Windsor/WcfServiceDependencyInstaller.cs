﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vantage.Service.WcfServiceHost.Windsor
{
    using Castle.Facilities.WcfIntegration;
    using Castle.MicroKernel.Registration;

    using Vantage.Engine.Contracts;
    using Vantage.Engine.OrderManagement;
    using Vantage.Service.Contracts;
    using Vantage.Service.DPScanner;
    using Vantage.Service.OrderManagement;
    using Vantage.Service.Symphony;
    using Vantage.Service.VIP;
    using Vantage.Service.Virtuoso;
    using Vantage.Util.Contracts;
    using Vantage.Util.Logger;

    public class WcfServiceDependencyInstaller : IWindsorInstaller
    {
        public void Install(Castle.Windsor.IWindsorContainer container, Castle.MicroKernel.SubSystems.Configuration.IConfigurationStore store)
        {
            container.AddFacility<WcfFacility>();
            container.Register(Component.For<ILogger>().ImplementedBy<VLogger>().LifeStyle.Singleton);

            container.Register(Component.For<IVIPService>().ImplementedBy<VIPService>());
            container.Register(Component.For<ISymphonyService>().ImplementedBy<SymphonyService>());
            container.Register(Component.For<IVirtuosoService>().ImplementedBy<VirtuosoService>());
            container.Register(Component.For<IDPScannerService>().ImplementedBy<DPScannerService>());
            container.Register(Component.For<IOrderManagementService>().ImplementedBy<OrderManagementService>());

            container.Register(Component.For<IOrderManagementEngine>().ImplementedBy<OrderManagementEngine>().LifeStyle.Transient);

        }
    }
}