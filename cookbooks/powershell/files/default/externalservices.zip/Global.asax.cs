﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

namespace Vantage.Service.WcfServiceHost
{
    using System.Diagnostics;

    using Castle.Windsor;
    using Castle.Windsor.Installer;

    using Vantage.DataAccess.NHibernate;
    using Vantage.Service.WcfServiceHost.Windsor;

    public class Global: System.Web.HttpApplication
    {
        //TODO: (Rana's) Work in Progress. Do not use this for now.
        public static IWindsorContainer Container;
        protected void Application_Start(object sender, EventArgs e)
        {
            Container = new WindsorContainer();
            Container.Install(new WcfServiceDependencyInstaller(), new NHibernateDependencyInstaller());
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {
            Container.Dispose();
        }
    }
}