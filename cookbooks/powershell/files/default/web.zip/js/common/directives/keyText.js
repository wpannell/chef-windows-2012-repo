/*
 * User: singhi5
 * Date: 12/5/13
 * Project: Vantage 3.0
 */

'use strict';

 angular.module('common.directives', [])
     .directive('keyin', ['$modal',function ($modal) {
         var textInputDirective = {
             restrict: "A",
             scope: {
                 textModel: "="
             },
             link: function (scope, elm, attrs) {

                 elm.bind("click", function() {

                     var dialogOptions = {
                         templateUrl: 'views/keyboard.html',
                         controller: 'keyboardController',
                         resolve: {
                             data: function () {
                                 return {Launcher:"Directive", Value: elm.val()};
                             }
                         }
                     };

                     var modalInstance = $modal.open(dialogOptions);

                     modalInstance.result.then(function (inputText) {
                         //scope.textModel = inputText;

                         ele.val(inputText);
                            if (!scope.$$phase) scope.$apply("textModel");

                     });
                 });
             }
         };

         return textInputDirective;
     }]);
