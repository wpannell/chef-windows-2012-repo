/*
 * User: biniwalh
 * Date: 12/18/13
 * Project: Vantage 3.0
 */
(function(){
'use strict';
        var specialInstruction = function ($modal){
            return {
                templateUrl: "views/specialInstructionsTemplate.html",
                restrict: "E",
                transclude: true,
                replace: true,
               scope: {
                  siModel:"=",
                  specimenId:"@",
                  caseAccessionNumber:"@"
                },
                controller:'addSpecialInstructionController',
                link: function(scope, elm, attr){}
            };
        };
        angular.module('common.specialInstructionDirective', []).directive('specialInstruction', ['$modal',  specialInstruction]);
}());