/*
 * User: singhi5
 * Date: 12/12/13
 * Project: Vantage 3.0
 */

'use strict';

angular.module('common.qualityIssueDirective', [])
    .directive('qualityIssue', [function () {
        var qualityIssue = {
            templateUrl: 'views/qualityIssueTemplate.html',
            restrict: "E",
            transclude: true,
            replace: true,
            scope: {
              qiModel:"=",
              specimenId:"@",
              caseAccessionNumber:"@"
            },
            controller: 'addQualityIssueController',
            link: function(scope, elm, attr) {

            }
        };

        return qualityIssue;
    }]);
