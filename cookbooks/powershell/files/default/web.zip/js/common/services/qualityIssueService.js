/*
 * User: singhi5
 * Date: 12/13/13
 * Project: Vantage 3.0
 */


(function () {
    'use strict';
    var services = angular.module('common.qualityIssueService', []);
    services.factory('qualityIssueService', ['$http',
        function ($http) {

            var qualityIssueService = {

                getQualityIssues : function (){

                   var future =  $http({method: 'GET', url: 'http://localhost:62011/api/surepath/GetQualityIssues', cache:false});
                   //var future =  $http({method: 'GET', url: 'data/qualityIssue.js', cache:false});

                    return future.then(function (response) {
                        return response.data;
                    });
                },
                addQualityIssue : function(qualityIssueWithResolution){

                    var future =  $http.post('http://localhost:62011/api/surepath/PostAddQualityIssue', qualityIssueWithResolution);

                    return future.then(function(response){
                           return response.data;
                    });
                }
            };
            return qualityIssueService;
        }
    ]);
})();
