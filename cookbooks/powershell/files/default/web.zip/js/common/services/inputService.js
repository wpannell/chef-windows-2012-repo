/*
 * User: singhi5
 * Date: 12/5/13
 * Project: Vantage 3.0
 */

'use strict';
(function () {
  var services = angular.module('common.inputService', []);
  services.factory('inputService', [
      '$rootScope',
    function ($rootScope) {
      var handle = '/Input',
          keyboardHandle = '/Keyboard',
          scannerHandle = '/Scanner',
          subscription;

      var inputService = {

        subscribe: function($scope, handler) {
            subscription =   $scope.$on(handle, function(event,props) {
                        handler(props);
                  });
        },

        setValidationMessage: function (validationData){
            //validationData format  = {ToSource: '/Keyboard or  /Scanner', message: 'Validation message', From:'LoginController or ScanController etc..', Action:'Validate/Unsubscribe'};
            $rootScope.$broadcast(validationData.ToSource, validationData);
        },

        unsubscribe: function () {
          subscription = undefined;
            $rootScope.$broadcast(keyboardHandle, {Action: 'Unsubscribe'});
        }
      };
      return inputService;
    }
  ]);
})();
