/*
 * User: singhi5
 * Date: 12/5/13
 * Project: Vantage 3.0
 */


(function () {
    'use strict';
  var services = angular.module('common.keyboardService', []);

    services.value('keyboardControlData', {ShiftPosition: "", Input: "", ValidationMessage: ""});

    services.factory('keyboardService', ['$http', function ($http) {

        var keyboardService = {
                data: {},

                get: function () {
                    var future =  $http({
                        method: 'GET', url: 'data/keyboard.js'
                    });

                    return future.then(function (response) {
                        keyboardService.data = response;
                        return keyboardService.data;
                    });
                }
        };
        return keyboardService;

    }]);



})();
