'use strict';
(function () {
  var services = angular.module('common.scannerService', []);
  services.factory('scannerService', ['$q', function ($q) {
    var handle = '/scanner', buffer = '', subscription;

    var wasEnterKeyScanned = function (keyEvent) {
      return keyEvent.keyCode === 13
    };

    return {
      subscribe: function () {
        var defer = $q.defer(), buffer = '';

        subscription = subscribe(handle, function (payload) {
          defer.resolve(payload);
        });
        return defer.promise
      },

      unsubscribe: function () {
        unsubscribe(subscription);
        subscription = undefined;
      },

      isSubscribed: function () {
        return subscription !== undefined;
      },

      buffer: function () {
        return buffer;
      },

      appendFor: function (keyEvent) {
        buffer += String.fromCharCode(keyEvent.charCode);
          alert('test');
      },

      set: function (text) {

        buffer = text + '\n';
        this.notifyEnterKeyScanned({keyCode: 13});
      },

      notifyEnterKeyScanned: function (keyEvent) {

         // alert('notifyEnterKeyScanned');

        if (!wasEnterKeyScanned(keyEvent)) {
          return;
        }
        var contents = buffer;
        buffer = '';
        publish(handle, [contents.substr(0, contents.length - 1)]);
      }
    };
  }]);
})();