/**
 * Created with JetBrains WebStorm.
 * User: biniwalh
 * Date: 12/18/13
 * Time: 5:09 PM
 * To change this template use File | Settings | File Templates.
 */

(function () {
    'use strict';
    var services = angular.module('common.specialInstructionService', []);
    services.factory('specialInstructionService', ['$http',
        function ($http) {
            var specialInstructionServiceURL = angular.getAppSection('Service').specialInstructionService;
            var specialInstructionService = {

                getspecialInstruction : function (){

                    //var future =  $http({method: 'GET', url: 'http://localhost:62011/api/surepath/GetSpecialInstruction', cache:false});
                    //var future =  $http({method: 'GET', url: 'data/SpecialInstructionList.js', cache:false});
                    var future =  $http({method: 'GET', url: specialInstructionServiceURL, cache:false});

                    return future.then(function (response) {
                        return response.data;
                    });
                }
            };
            return specialInstructionService;
        }
    ]);
})();
