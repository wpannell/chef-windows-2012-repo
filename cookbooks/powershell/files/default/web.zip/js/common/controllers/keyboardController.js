/*
 * User: singhi5
 * Date: 12/5/13
 * Project: Vantage 3.0
 */

'use strict';

angular.module('common.keyboardController', []).

    controller('keyboardController', [
      '$rootScope',
      '$modalInstance',
      'keyboardService',
      'keyboardControlData',
      'data',
    function (
        $scope,
        $modalInstance,
        keyboardService,
        keyboardControlData,
        data) {

      $scope.ControlData = keyboardControlData;

        $scope.$on('/Keyboard', function(event,props) {

            switch (props.Action){
                case "Validate":
                    keyboardControlData.ValidationMessage =  props.message;
                    //alert(props.message);
                    break;
                case "Unsubscribe":
                    keyboardControlData.ValidationMessage = "";
                    $modalInstance.dismiss('cancel');
                    break;
            }
        }) ;

        keyboardService.get().then(function (response) {
            $scope.Keyboard = response.data;
        });

        if(data === undefined) {
            keyboardControlData.Input = "";
        }
        else {
            keyboardControlData.Input = data.Value;
        }

        $scope.onSpaceClick = function (sender) {

          keyboardControlData.Input += " ";
          Revert();
        };

        $scope.onClick = function (sender) {
               //    alert(sender.DisplayValue);
          keyboardControlData.Input += sender.DisplayValue;
          Revert();
        };

        $scope.expr = function(expr, locals) {
            return $scope.$eval(expr, locals);
        };

        $scope.onBackSpaceClick = function (sender) {
          if (keyboardControlData.Input.length > 0) {
            keyboardControlData.Input = keyboardControlData.Input.slice(0, -1);
          }
        };

        $scope.onShiftClick = function (sender) {

          switch (sender.DisplayValue) {
            case "shift":

              ConvertCase(true);
              keyboardControlData.ShiftPosition = "On";

              break;

            case "SHIFT":

              ConvertCase(false);
              keyboardControlData.ShiftPosition = "Off";

              break;
            default:
              break;
          }
        };

       /* $scope.onCharKeyClick = function (sender) {

            switch (sender.DisplayValue) {
                case "123#":

                    ConvertChar();
                   // keyboardControlData.CharPosition = "On";
                    sender.DisplayValue = "xyz";

                    break;

                case "xyz":

                    ConvertCase(false);
                    keyboardControlData.ShiftPosition = "Off";
                    sender.DisplayValue = "123#";

                    break;
                default: break;
            }
        }      */

        $scope.close = function(sender) {
            $modalInstance.dismiss('cancel');
        };

        /*function ConvertChar() {

            angular.forEach($scope.Keyboard, function (row) {

                if (row.CharApplicable == 1) {

                    row.DisplayValue = row.Char;

                }
            })
        } */

        $scope.onEnterClick = function (sender) {
            $scope.$broadcast('/Input', {Source: '/Keyboard', Data: keyboardControlData.Input.toString()});

            if(data !== undefined && data.Launcher==="Directive") {
                $modalInstance.close(keyboardControlData.Input);
            }
        };

        $scope.onShiftDbClick = function (sender) {
          ConvertCase(true);
          keyboardControlData.ShiftPosition = "On-Lock";
        };

        function Revert() {
          if (keyboardControlData.ShiftPosition === "On") {
            keyboardControlData.ShiftPosition = "Off";
            ConvertCase(false);
          }
        }

        function ConvertCase(isUpper) {

          angular.forEach($scope.Keyboard, function (row) {

            if (row.CaseApplicable === '1') {

              if (isUpper) {
                row.DisplayValue = row.UpperCase;
              } else {
                row.DisplayValue = row.LowerCase;
              }

              if (row.DisplayValue === "SHIFT") {
                row.Css += " shift";
              }
              else if (row.DisplayValue === "shift") {
                if (row.Css.match(/shift_mar55/i)) {
                  row.Css = "shift_mar55";
                } else {
                  row.Css = "";
                }

              }

            }
          });
        }
      }]);


