/**
 * Created with JetBrains WebStorm.
 * User: biniwalh
 * Date: 12/18/13
 * Time: 5:05 PM
 * To change this template use File | Settings | File Templates.
 */

(function () {
    'use strict';
         var specialInstructionController =   function ($scope,$modalInstance, data) {

                var controlData = {
                    specimenId: data.specimenId,
                    caseAccessionNumber: data.caseAccessionNumber,
                    selectedSpecialInstruction : data.selectedSpecialInstruction,
                    showSelectedCount : 0,
                    ShowSelectedList:[]
                };

             $scope.specialInstruction = data.specialInstructionList;

                $scope.controlData = controlData;


             if($scope.controlData.selectedSpecialInstruction !== null && $scope.controlData.selectedSpecialInstruction.length >= 1)
             {
                 var indexSI;
                 for (indexSI in $scope.controlData.selectedSpecialInstruction)
                    {
                 var id = $scope.controlData.selectedSpecialInstruction[indexSI].Id;
                 var filterData =  $scope.specialInstruction.filter(function(val){
                     return val.Id ==  id;
                 });
                 if(filterData[0] !== null)
                 {
                    filterData[0].CustProp = {'Disabled':true, Css:'disabled'};
                 }
                }
             }
                //Display the Dialog
                $scope.showspecialInstruction = true;

                $scope.onSpecialInstructionSelected = function(si,isChecked){
                    if(si !== null)
                    {
                        //Create the collection of Selected Special Instruction
                        if(isChecked)
                        {
                            //Add to the Collection
                            $scope.controlData.ShowSelectedList.push(si);
                        }
                        else
                        {
                            //Remove from the collection
                            var index = $scope.controlData.ShowSelectedList.indexOf(si);
                            $scope.controlData.ShowSelectedList.splice(index,1);
                        }

                        //Count of Selected Special Instruction
                        $scope.controlData.showSelectedCount = $scope.controlData.ShowSelectedList.length;
                    }
                };


                $scope.cancel = function() {
                    $modalInstance.dismiss('Closed');
                };

                $scope.applyIssue = function (){

                    $scope.showspecialInstruction = false;
                    /*
                    $scope.resolutions = $scope.qualityIssues.filter(function(val){
                        return val.Id ===  $scope.controlData.qiWRes.QualityIssue.Id;
                    })[0].QualityResolutions;
                    */
                    $modalInstance.close($scope.controlData);
                };


            };

    //Register Controller & Inject
    angular.module('common.specialInstructionController',[]).controller('specialInstructionController', [
        '$scope',
        '$modalInstance',
        'data',specialInstructionController]);

})();