/*
 * User: singhi5
 * Date: 12/5/13
 * Project: Vantage 3.0
 */

'use strict';
(function () {
  angular.module('common.loginController', []).
      controller('loginController', [
        '$scope',
        '$location',
        'inputService',
        function ($scope, $location, inputService, $http) {

            inputService.subscribe($scope, function(message){

                /* The validation logic will change as part of login user story*/
                if(message.Data === 'admin'){

                    inputService.unsubscribe();
                    $location.url('/surepathscan');
                }
                else
                {
                    inputService.setValidationMessage({Action: 'Validate', ToSource: message.Source, message: 'Invalid login id: ' + message.Data, From:'LoginController'});
                }
            });

  }]);
})();