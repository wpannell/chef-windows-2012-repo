/*
 * User: singhi5
 * Date: 12/5/13
 * Project: Vantage 3.0
 */

'use strict';
(function () {
  angular.module('common.footerController', []).
      controller('footerController', [
          '$scope',
          '$modal',
      function (
          $scope,
          $modal
          ) {

          var dialogOptions = {
            templateUrl: 'views/keyboard.html',
            controller: 'keyboardController',
              resolve: {
                  data: function () {
                      return undefined;
                  }
              }
          };

          $scope.openKeyboard = function(){
              var modalInstance = $modal.open(dialogOptions);
          };
        }]);
})();