/*
 * User: singhi5
 * Date: 12/13/13
 * Project: Vantage 3.0
 */


(function () {
    'use strict';
    angular.module('common.qualityIssueController', []).
        controller('qualityIssueController', [
            '$scope',
            '$modalInstance',
            'data',
            function ($scope, $modalInstance, data) {

                var qualityIssueWithResolutions = {
                    "QualityIssue":{
                        "Id":"",
                        "Name":"",
                        "Description":"",
                        "IsActive":true
                    },
                    "QualityResolution":{
                        "Id":"",
                        "Name":"",
                        "Description":"",
                        "IsActive":true},
                    "SampleId": data.specimenId
                };

                var controlData = {
                    specimenId: data.specimenId,
                    caseAccessionNumber: data.caseAccessionNumber,
                    qiWRes: qualityIssueWithResolutions,
                    selectedIssues: data.selectedIssues
                };

                $scope.qualityIssues = data.qualityIssues;

                $scope.controlData = controlData;

                var i;

                for (i in $scope.controlData.selectedIssues)
                {
                    var id = $scope.controlData.selectedIssues[i].qualityIssueId;

                    $scope.qualityIssues.filter(function(val){
                        return val.Id ===  id;
                    })[0].CustProp = {'Disabled':true, Css:'disabled'};
                }

                $scope.showQualityIssue = true;
                $scope.showQIApplyButton = true;
                $scope.showResApplyButton = true;

                $scope.onIssueSelected = function(qi){
                    if(qi.CustProp !== undefined) {
                        return;
                    }

                    $scope.controlData.qiWRes.QualityIssue.Name = qi.Name;
                    $scope.controlData.qiWRes.QualityIssue.Id = qi.Id;
                    $scope.controlData.qiWRes.QualityIssue.Description = qi.Description;
                    $scope.showQIApplyButton = false;
                };

                $scope.cancel = function() {
                    $modalInstance.dismiss('Closed');
                };

                $scope.applyIssue = function (){

                    if($scope.controlData.qiWRes.QualityIssue.Id === "")  {
                        return;
                    }

                    $scope.showQualityIssue = false;

                    $scope.resolutions = $scope.qualityIssues.filter(function(val){
                       return val.Id ===  $scope.controlData.qiWRes.QualityIssue.Id;
                    })[0].QualityResolutions;
                };

                $scope.onResolutionSelected = function(re){

                    $scope.controlData.qiWRes.QualityResolution.Id = re.Id;
                    $scope.controlData.qiWRes.QualityResolution.Name = re.Name;
                    $scope.controlData.qiWRes.QualityResolution.Description = re.Description;
                    $scope.showResApplyButton = false;

                };

                $scope.applyResolution = function (){
                    if($scope.controlData.qiWRes.QualityResolution.Id === "")  {
                        return;
                    }

                    $modalInstance.close($scope.controlData);
                };

            }]);
})();