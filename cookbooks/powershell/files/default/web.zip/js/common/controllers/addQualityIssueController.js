/*
 * User: singhi5
 * Date: 12/23/13
 * Project: Vantage 3.0
 */


(function () {
    'use strict';
    angular.module('common.addQualityIssueController', []).
        controller('addQualityIssueController', [
            '$scope',
            '$modal',
            'qualityIssueService',
            function (
                $scope,
                $modal,
                qualityIssueService
                ) {

                $scope.$watch('qiModel', function(newVal, oldVal) {
                    if(newVal !== undefined) {
                        $scope.qualityIssueWithResolutions = newVal;
                    }
                });

                qualityIssueService.getQualityIssues().then(function(response){

                    $scope.qualityIssues = response;

                });

                $scope.qiDialog = function() {

                    var qiList = [];
                    var qiwr;

                    for (qiwr in $scope.qualityIssueWithResolutions)
                    {
                        qiList.push({'qualityIssueId': $scope.qualityIssueWithResolutions[qiwr].QualityIssue.Id});
                    }

                    var specimenId = this.specimenId,
                        caseAccessionNumber = this.caseAccessionNumber;

                    var dialogOptions = {
                        templateUrl: 'views/qualityIssues.html',
                        controller: 'qualityIssueController',
                        backdrop: 'static',
                        resolve: {
                            data: function () {
                                return {'specimenId': specimenId, 'caseAccessionNumber': caseAccessionNumber, 'selectedIssues': qiList, 'qualityIssues': $scope.qualityIssues};
                            }
                        }
                    };

                    var modalInstance = $modal.open(dialogOptions);

                    modalInstance.result.then(function (dialogResult) {

                       // qualityIssueService.addQualityIssue(dialogResult.qiWRes);

                        dialogResult.qiWRes.Id = $scope.qualityIssueWithResolutions.length + 1;
                        $scope.qualityIssueWithResolutions.push(dialogResult.qiWRes);

                    });

                };


            }]);
})();