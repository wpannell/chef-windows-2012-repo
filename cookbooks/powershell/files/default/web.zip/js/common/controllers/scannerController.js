'use strict';
(function () {
  angular.module('common.scannerController', []).
      controller('scannerController', [
        '$scope',
        'scannerService',
    function ($scope, scanner) {
      $scope.whenKeyScanned = scanner.appendFor;
      $scope.whenEnterKeyScanned = scanner.notifyEnterKeyScanned;

        $scope.scanTest = "";

        $scope.getInput = function () {
            alert($scope.scanTest);
        };
    }]);



})();