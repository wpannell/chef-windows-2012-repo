/**
 * Created with JetBrains WebStorm.
 * User: biniwalh
 * Date: 12/30/13
 * Time: 5:58 PM
 * To change this template use File | Settings | File Templates.
 */

(function(){
    'use strict';
    var addSpecialInstructionController = function($scope,$modal,specialInstructionService){

        $scope.$watch('siModel', function(newVal, oldVal) {
            if(newVal !== undefined) {
                $scope.specialInstruction = newVal;
            }
        });

        //Get the list of Special Instruction
        specialInstructionService.getspecialInstruction().then(function(response){
            $scope.specialInstructionList = response;
        });

        $scope.siDialog = function() {

            var specimenId = this.specimenId,
                caseAccessionNumber = this.caseAccessionNumber,
                selectedSpecialInstruction = this.siModel;


            var dialogOptions = {
                templateUrl: 'views/specialInstructions.html',
                controller: 'specialInstructionController',
                backdrop:'static',
                keyboard: false,
                resolve: {
                    data: function () {
                        return {'specimenId': specimenId,
                            'caseAccessionNumber': caseAccessionNumber,
                            'selectedSpecialInstruction':selectedSpecialInstruction,
                            'specialInstructionList' : $scope.specialInstructionList
                        };
                    }
                }
            };

            var modalInstance = $modal.open(dialogOptions);

            modalInstance.result.then(function (dialogResult) {
                //dialogResult.siWRes.Id = $scope.specialInstruction.length + 1;
                //$scope.qualityIssueWithResolutions.push(dialogResult.siWRes);

                //$scope.specialInstruction =  $scope.specialInstruction.concat(dialogResult.ShowSelectedList);

                var i;
                for (i in dialogResult.ShowSelectedList)
                {
                    var obj = dialogResult.ShowSelectedList[i];
                    $scope.specialInstruction.push(obj);
                }
            });
        };
    };
    //Register Controller & Inject
    angular.module('common.addSpecialInstructionController',[]).controller('addSpecialInstructionController', ['$scope','$modal','specialInstructionService',addSpecialInstructionController]);

 })();