'use strict';
(function () {
  angular.module('cytology.filters', []).
      filter('prettyName',function () {
    return function (firstName, lastName) {
      return lastName + ', ' + firstName;
    }
  }).filter('shortName', function () {
    return function (firstName, lastName) {
      return lastName + ', ' + firstName.substr(0, 1);
    }
  });
})();