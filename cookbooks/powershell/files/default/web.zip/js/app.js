'use strict';

// Declare app level module which depends on filters, and services
angular.module('vantage', [
  'ngRoute',
  'ui.bootstrap',

  'common.scannerService',
  'common.keyboardService',
  'common.inputService',
  'common.qualityIssueService',
  'common.directives',
  'common.qualityIssueDirective',

  'common.scannerController',
  'common.keyboardController',
  'common.footerController',
  'common.loginController',
  'common.qualityIssueController',
  'common.addQualityIssueController',

   //SurePath
   'surepath.Controllers',
   'surepath.surepathWebService'
   ,'surepath.sampleDetailsWebService'
   ,'surepath.ControllersSlidePage'
   ,'surepath.slideDetailsWebService'


]).
config(['$routeProvider', function($routeProvider) {

    $routeProvider.when('/default', {templateUrl: 'views/default.html'});
    $routeProvider.when('/login', {templateUrl: 'views/login.html'});
    $routeProvider.when('/scan', {templateUrl: 'views/scan.html'});

 /*----------------  SUREPATH --------------------*/
 /* $routeProvider.when('/surepathscan', {templateUrl: 'views/surepath/SurePathSpecimen.html',controller:'surepathScanController'});*/
  $routeProvider.when('/surepathtube/:ID', {templateUrl: 'views/surepath/SurePathTubePage.html',controller:'surepathSampleDetailsController'});
  $routeProvider.when('/surepathslide', {templateUrl: 'views/surepath/SurePathSlidePage.html',controller:'surepathSlideDetailsController'});
 /*----------------  SUREPATH --------------------*/

  $routeProvider.otherwise({redirectTo: '/login'});
}]);
