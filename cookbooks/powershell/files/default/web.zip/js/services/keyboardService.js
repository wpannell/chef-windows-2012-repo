'use strict';
(function () {
  var services = angular.module('cytology.keyboardService', []);


  services.factory('keyboardData', function ($http) {
    return {
      get: function (onSuccess) {
        $http({
          method: 'GET', url: 'data/USKeyboard.js'
        }).
            success(function (data, status, headers, config) {
              onSuccess(data);
            })
      }
    };
  });

    /*India Team: Added a new keyboard service*/
    services.factory('keyboardService', ['$http','$q', function ($http,$q) {
        var
            handle = '/Keyboard',
            buffer = '',
            notifyOnUnSubscribe,
            subscription;
        var keyboardService = {
            data: {},

            get: function () {
                var future =  $http({
                    method: 'GET', url: 'data/USKeyboard.js'
                });

                return future.then(function (response) {
                    keyboardService.data = response;
                    return keyboardService.data;
                });
            },

            notifyUnsubscribe: function (closeDialogue){

                notifyOnUnSubscribe =   closeDialogue;
            },

                subscribe: function () {
                    var defer = $q.defer(),
                        buffer = '';
                    subscription = subscribe(handle, function (payload) {
                        defer.resolve(payload);
                    });
                    return defer.promise
                },

                unsubscribe: function () {
                    unsubscribe(subscription);
                    subscription = undefined;

                    if(notifyOnUnSubscribe !== undefined )  {

                        notifyOnUnSubscribe();
                    }
                },

                isSubscribed: function () {
                    return subscription !== undefined;
                },
                buffer: function () {
                    return buffer;
                },
                appendFor: function (keyEvent) {
                    buffer += String.fromCharCode(keyEvent.charCode);
                },
                set: function (text) {
                    buffer = text;
                    this.notifyEnterKeyScanned({keyCode: 13});
                },
                notifyEnterKeyScanned: function (keyEvent) {
                    var contents = buffer;
                    buffer = '';
                    publish(handle, [contents]);
                }


        };
        return keyboardService;



    }]);

    /*India Team: End Changes*/



})();
