'use strict';
(function () {
  angular.module('cytology.specialInstructionsController', []).
      controller('SpecialInstructionsController', ['$scope', 'caseService',
    function ($scope, caseService) {
    }
  ]);
})();