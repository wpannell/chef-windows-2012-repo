'use strict';
(function () {
  angular.module('cytology.footerController', []).
    /* STC Team# Start Changes# Modified footer controller to pass in the keyboard data service */
      controller('FooterController', [
          '$scope',
          'clock',
          '$dialog',
      function (
          $scope,
          clock,
          $dialog
          ) {
          $scope.clock = clock;
          var dialogOptions = {
            backdrop: true,
            keyboard: true,
            backdropClick: true,
            templateUrl: 'views/keyboardView.html',
            controller: 'KeyboardController'
          };

          $scope.openKeyboard = function(){
              $dialog.dialogRef = $dialog.dialog(dialogOptions);
              $dialog.dialogRef.open();
          };
        }]);
  /* STC Team# End Changes# footer controller */
})();