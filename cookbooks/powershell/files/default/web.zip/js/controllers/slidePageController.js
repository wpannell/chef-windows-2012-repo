'use strict';
(function () {
  angular.module('cytology.slidePageController', []).
      controller('SlidePageController', [
        '$scope',
        '$location',
        'scanner',
        'caseService',
        '$dialog',
      function ($scope, $location, scanner, caseService, $dialog) {
    var container = caseService.page.container,
        samples = caseService.page.sample.samples;

    $scope.case = caseService.case;
    $scope.patient = caseService.patient;
    $scope.specimen = container;
    $scope.slides = samples;

    scanner.subscribe().then(function (barcode) {
      caseService.getCaseFor(barcode, function (caseService) {
        scanner.unsubscribe();
        $location.url(caseService.page.url);
      });
    });

    $scope.getTestInput = function () {
      var barcode = $scope.case;
      caseService.getCaseFor(barcode, function (caseService) {
        scanner.unsubscribe();
        $location.url(caseService.page.url);
      });
    };
  }]);
})();