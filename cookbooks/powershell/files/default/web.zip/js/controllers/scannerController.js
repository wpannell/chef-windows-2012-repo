'use strict';
(function () {
  angular.module('cytology.scannerController', []).
      controller('ScannerController', [
        '$scope',
        'scanner',
        'userService',
        'caseService',
    function ($scope, scanner, userService, caseService) {
      $scope.whenKeyScanned = scanner.appendFor;
      $scope.whenEnterKeyScanned = scanner.notifyEnterKeyScanned;
      $scope.userModel = userService;
      $scope.caseModel = caseService;
    }]);
})();