/**
 * Created with JetBrains WebStorm.
 * User: biniwalh
 * Date: 12/6/13
 * Time: 4:33 PM
 * To change this template use File | Settings | File Templates.
 */
'use strict';
(function () {
    var services = angular.module('surepath.surepathWebService', []);


    services.factory('surepathWebService', ['$http', function ($http) {

        var surepathWebService = {
            data: {},

            get: function (barCodeID) {

                var future =  $http({
                    method: 'GET', url: 'http://localhost:62011/api/surepath/GetIsValidSpecimen/' + barCodeID
                });


                return future.then(function (response) {
                    surepathWebService.data = response.data;
                    return surepathWebService.data;
                });
            }
        };
        return surepathWebService;

    }]);
})();