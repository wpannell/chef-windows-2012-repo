/**
 * Created with JetBrains WebStorm.
 * User: biniwalh
 * Date: 12/6/13
 * Time: 4:33 PM
 * To change this template use File | Settings | File Templates.
 */
(function () {
    'use strict';
    var services = angular.module('surepath.surepathWebService', []);

    services.factory('surepathWebService', ['$http', function ($http) {
        var surepathWebServiceURL = angular.getAppSection('Service').surepathWebService;

        var surepathWebService = {
            data: {},

            get: function (ID) {

                var future =  $http({
                    //method: 'GET', url: 'http://localhost:62011/api/surepath/GetIsValidSample/' + ID
                    method: 'GET', url: surepathWebServiceURL + ID
                });

                return future.then(function (response) {
                    surepathWebService.data = response.data;
                    return surepathWebService.data;
                });
            }
        };
        return surepathWebService;

    }]);
})();