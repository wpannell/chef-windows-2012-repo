/**
 * Created with JetBrains WebStorm.
 * User: karankaa
 * Date: 12/12/13
 * Time: 11:35 PM
 * To change this template use File | Settings | File Templates.
 */
(function () {
    var services = angular.module('surepath.slideDetailsWebService', []);

    services.factory('slideDetailsWebService', ['$http', function ($http) {

          var slideDetailsWebService = {
            data: {},

            get: function(humanreadableID) {
                var future =  $http({
                    // method: 'GET', url: 'data/patient.js'
                    method: 'GET', url: 'http://localhost:62011/api/surepath/GetSlideDetails/' +'C14-4457 A1'
                });

                return future.then(function (response) {
                    slideDetailsWebService.data = response;
                    return slideDetailsWebService.data;
                });
            }
        };
        return slideDetailsWebService;

    }]);
})();