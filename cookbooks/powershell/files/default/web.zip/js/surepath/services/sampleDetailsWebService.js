'use strict';
(function () {
    var services = angular.module('surepath.sampleDetailsWebService', []);


    services.factory('sampleDetailsWebService', ['$http', function ($http) {

        var sampleDetailsWebServiceURL = angular.getAppSection('Service').sampleDetailsWebService;
        var sampleDetailsWebService = {
            data: {},

            get: function(humanreadableID) {
                var future =  $http({
                   // method: 'GET', url: 'data/tubedata.js'
                    //method: 'GET', url: 'http://localhost:62011/api/surepath/GetSpecimenDetails/' + humanreadableID
                    method: 'GET', url: sampleDetailsWebServiceURL + humanreadableID
                });

                return future.then(function (response) {
                    sampleDetailsWebService.data = response;
                    return sampleDetailsWebService.data;
                });
            }
        };
        return sampleDetailsWebService;

    }]);
})();