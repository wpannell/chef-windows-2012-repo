'use strict';
(function () {
    var services = angular.module('surepath.sampleDetailsWebService', []);


    services.factory('sampleDetailsWebService', ['$http', function ($http) {


        var sampleDetailsWebService = {
            data: {},

            get: function(humanreadableID) {
                var future =  $http({
                   // method: 'GET', url: 'data/patient.js'
                    method: 'GET', url: 'http://localhost:62011/api/surepath/GetSpecimenDetails/' + humanreadableID
                });

                return future.then(function (response) {
                    sampleDetailsWebService.data = response;
                    return sampleDetailsWebService.data;
                });
            }
        };
        return sampleDetailsWebService;

    }]);
})();