/**
 * Created with JetBrains WebStorm.
 * User: biniwalh
 * Date: 12/6/13
 * Time: 4:15 PM
 * To change this template use File | Settings | File Templates.
 */
'use strict';
(function () {
     angular.module('surepath.ControllersTubePage', []).
    controller('surepathSampleDetailsController', [
            '$scope',
            '$location',
             '$routeParams',
             'inputService',
             'sampleDetailsWebService',
             function ($scope, $location,$routeParams, inputService,sampleDetailsWebService) {

                 sampleDetailsWebService.get($routeParams.ID).then(function (response) {
                         $scope.specimen = response.data;
                     });
             }]);
})();