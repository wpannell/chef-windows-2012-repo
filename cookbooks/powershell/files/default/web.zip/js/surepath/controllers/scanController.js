/**
 * Created with JetBrains WebStorm.
 * User: biniwalh
 * Date: 12/6/13
 * Time: 4:15 PM
 * To change this template use File | Settings | File Templates.
 */
'use strict';
(function () {
var module =    angular.module('surepath.Controllers', []);

        module.controller('surepathScanController', [
            '$scope',
            '$location',
            'inputService',
            'surepathWebService',
            function ($scope, $location, inputService,surepathWebService) {

                inputService.subscribe($scope, function(message)
                {
                    surepathWebService.get(message.Data).then(function(response){
                        if(response == 'true'){
                            inputService.unsubscribe();
                            $location.url('/surepathtube/' + message.Data );
                        }
                        else
                        {
                            inputService.setValidationMessage(
                                {
                                    Action: 'Validate',
                                    ToSource: message.Source,
                                    message: 'Invalid Specimen, Tube or Slide ID : ' + message.Data,
                                    From:'LoginController'
                                }
                            );
                        }
                    });

                });

            }]);
})();