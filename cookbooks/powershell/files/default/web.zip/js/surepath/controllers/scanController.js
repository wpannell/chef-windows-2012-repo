/**
 * Created with JetBrains WebStorm.
 * User: biniwalh
 * Date: 12/6/13
 * Time: 4:15 PM
 * To change this template use File | Settings | File Templates.
 */

(function (){
    'use strict';
        var surePathScanController =  function ($scope, $location, inputService,surepathWebService){

                inputService.subscribe($scope, function(message)
                {
                    surepathWebService.get(message.Data).then(function(response){

                        switch(response.SampleType)
                        {
                            case 'Specimen':
                                inputService.unsubscribe();
                                $location.url('/surepathtube/' + message.Data );
                                break;
                            case 'Tube':
                            case 'Slide':
                                inputService.unsubscribe();
                                $location.url('/surepathslide/' + message.Data );
                                break;
                            default:
                                inputService.setValidationMessage(
                                    {
                                        Action: 'Validate',
                                        ToSource: message.Source,
                                        message: 'Invalid Specimen, Tube or Slide ID : ' + message.Data,
                                        From:'LoginController'
                                    }
                                );
                        }
                    });

                });
        };

   //Register Controller & Inject
   angular.module('surepath.Controllers',[]).controller('surepathScanController', ['$scope','$location','inputService','surepathWebService',surePathScanController]);


})();