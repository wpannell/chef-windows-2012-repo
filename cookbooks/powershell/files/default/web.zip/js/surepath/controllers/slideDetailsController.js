/**
 * Created with JetBrains WebStorm.
 * User: karankaa
 * Date: 12/12/13
 * Time: 11:53 PM
 * To change this template use File | Settings | File Templates.
 */
(function () {
    angular.module('surepath.ControllersSlidePage', []).
        controller('surepathSlideDetailsController', [
            '$scope',
            '$location',
            '$routeParams',

            'inputService',
            'slideDetailsWebService',
            function ($scope, $location,$routeParams, inputService,slideDetailsWebService) {

                    slideDetailsWebService.get($routeParams.ID).then(function (response) {
                    $scope.specimen = response.data;
                });
            }]);
})();