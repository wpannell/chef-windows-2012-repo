{
    "SpecimenType":"null",
    "SpecimenName":"null",
    "SpecimenDescription":"GYN",
    "SurgicalProcedureName":"NA",
    "SurgicalProcedureDescription":"NA",
    "preprocess":"false",
    "Id":"0",
    "BarCode":"C14-4457 A",
    "Sequence":"A",
    "HumanReadableId":"C14-4457 A",
    "TechConsultId":"1234KD","CaseId":"C14-4457","IsActive":true,"LastPrintDate":null,"SpecialInstructions":[{"Id":1,"Name":"Special Instruction 1","Description":"Special Instruction Desc 1","CanBeHeld":"Yes","IsActive":true}],"QualityIssueWithResolutions":[{"Id":0,"QualityIssue":{"Id":1,"Name":"Quality Issues 1","Description":"Quality Description 1","IsActive":false,"QualityResolutions":null},"QualityResolution":{"Id":1,"Name":"Quality Resolution 1","Description":"Quality Resolution Desc 1","IsActive":false},"updatedDate":"2013-12-07T18:04:54.5346041+05:30"}],"StainOrder":{"Id":0,"Cases":{"Id":0,"LISUniqueId":"1234","CaseAccessionNumber":"C14-4457 A","TechConsultCaseId":"TC-123-AS","DateOfService":"2013-12-07T18:04:54.5346041+05:30","ScannedRequisitionForm":"Path: googledrive","IsActive":true,"Patient":{"Id":0,"FirstName":"Patricsia","MiddleName":"M","LastName":"Harris","DateOfBirth":"1969-09-01T00:00:00","Gender":"Female","MedicalRecordNumber":"MR9089789","Prefix":"Dr.","Suffix":"","Case":null},"Physician":null,"StainOrders":null,"Site":null},"OrderRequestType":1,"OrderSequenceNumber":1,"OrderingFacilityCode":"OF-123-567","OrderingFacilityName":"Ordering Facility","IsProcessed":false,"IsActive":true,"ObservationDate":"2013-12-07T18:04:54.5346041+05:30","ReceivedDate":"2013-12-07T18:04:54.5346041+05:30","AdvancedStainerKeyCode":null,"IsStat":false,"SlideLevel":"1","LISOrderNumber":"C14-4457","StainProtocol":null,"Pathologist":null,"Specimens":null,"Blocks":null,"Tubes":null,"Slides":null,"SupplementalInformation":null,"Samples":null}}
