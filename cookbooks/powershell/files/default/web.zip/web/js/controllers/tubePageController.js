'use strict';
(function () {angular.module('cytology.tubePageController',[]).
    controller('TubePageController', [
    '$scope',
    '$location',
    'inputService',
    'caseService',
    '$dialog',
  function (
      $scope,
      $location,
      inputService,
      caseService,
      $dialog) {
    var
        openedMessageBox,
        wasClosed = false,
        container = caseService.page.container,
        samples = caseService.page.sample.samples;
    var qualityOptions = {
      backdrop: true,
      keyboard: true,
      backdropClick: true,
      templateUrl: 'views/QualityIssuesPopUpView.html'
    };
    var instructionOptions = {
      backdrop: true,
      keyboard: true,
      backdropClick: true,
      templateUrl: 'views/SpecialInstructionsPopUpView.html'
    };
    var resolutionsOptions = {
      backdrop: true,
      keyboard: true,
      backdropClick: true,
      templateUrl: 'views/ResolutionsPopUpView.html'
    };
    $scope.qualityIssues = function() {
      $dialog.dialog(qualityOptions).open();
    };
    $scope.specialInstructions = function() {
      $dialog.dialog(instructionOptions).open();
    };
    $scope.resolutions = function() {
      $dialog.dialog(resolutionsOptions).open();
    };

    $scope.case = caseService.case;
    $scope.patient = caseService.patient;
    $scope.specimen = container;
    $scope.tubes = samples;
    $scope.instructions = caseService.instructions;

      inputService.subscribe().then(function(barcode) {
      caseService.getCaseFor(barcode, function (caseService) {
          inputService.unsubscribe();
        $location.url(caseService.page.url);
      });
    });

    caseService.whenPatientChanged(function (patient) {
      if (!_.isEqual(patient, $scope.patient)) {
        if (openedMessageBox !== undefined && openedMessageBox.isOpen) {
          wasClosed = true;
          openedMessageBox.close();
        }
        var title = 'Patient changed: ';
        var message =
            'FROM: ' +
            $scope.patient.lastname + ', ' +
            $scope.patient.firstname +
            ' gender: ' + $scope.patient.gender +
            ' dob: ' + $scope.patient.dob + ' ' +
            'TO: ' +
            patient.lastname + ', ' + patient.firstname +
            ' gender: ' + patient.gender +
            ' dob: ' + patient.dob;

        var buttons = [
          {result: 'ok', label: 'OK', cssClass: 'btn-primary'}
        ];

        openedMessageBox = $dialog.messageBox(title, message, buttons);
        openedMessageBox.open().then(function () {
          if (wasClosed) {
            wasClosed = false;
          } else {
            $scope.patient = patient;
          }
        });
      }
    });

    $scope.getTestInput = function() {
      var barcode = $scope.case;
      caseService.getCaseFor(barcode, function (caseService) {
          inputService.unsubscribe();
        $location.url(caseService.page.url);
      });
    };
  }]);
})();