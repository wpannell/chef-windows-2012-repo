'use strict';
(function () {
  angular.module('cytology.loginController', []).
      controller('LoginController', [
        '$scope',
        '$location',
        'inputService',
        'userService',
        function ($scope, $location, inputService, userService) {
    userService.reset();
    $scope.userModel = userService;

    var UserLogin = function (userID) {
      return userService.get(userID).then(function (user) {
        $scope.userModel.user = user;
        inputService.unsubscribe();
        $location.url('/scan');
      })
    };

    inputService.subscribe().then(UserLogin);

    $scope.getTestInput = function () {
      userService.get($scope.test).then(function () {
        inputService.unsubscribe();
        $location.url('/scan');
      })
    };
  }]);
})();