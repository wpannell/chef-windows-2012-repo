'use strict';

angular.module('cytology.keyboardController', []).
  /*STC Team# Start Changes# Modified keyboard controler to handler keyboard events*/
    controller('KeyboardController', [
      '$scope',
      '$dialog',
      'keyboardService',
      'keyboardControlData',
    function (
        $scope,
        $dialog,
        keyboardService,     /*India Team: Added ref to keyboard service*/
        keyboardControlData) {

      $scope.ControlData = keyboardControlData;


        keyboardService.notifyUnsubscribe(function (){

            $dialog.dialogRef.close();

        });

        /*India Team: Changed the service call*/
        keyboardService.get().then(function (response) {
            $scope.Keyboard = response.data;
        });
       /*India Team: End changes*/

        keyboardControlData.Input = "";

        $scope.onSpaceClick = function (sender) {

          keyboardControlData.Input += " ";
          Revert();
        }

        $scope.onClick = function (sender) {

          keyboardControlData.Input += sender.DisplayValue;
          Revert();
        }

        $scope.onBackSpaceClick = function (sender) {
          if (keyboardControlData.Input.length > 0) {
            keyboardControlData.Input = keyboardControlData.Input.slice(0, -1);
          }
        }

        $scope.onShiftClick = function (sender) {

          switch (sender.DisplayValue) {
            case "shift":

              ConvertCase(true);
              keyboardControlData.ShiftPosition = "On";

              break;

            case "SHIFT":

              ConvertCase(false);
              keyboardControlData.ShiftPosition = "Off";

              break;
            default:
              break;
          }
        }

        $scope.onCharKeyClick = function (sender) {

            switch (sender.DisplayValue) {
                case "123#":

                    ConvertChar();
                   // keyboardControlData.CharPosition = "On";
                    sender.DisplayValue = "xyz";

                    break;

                case "xyz":

                    ConvertCase(false);
                    keyboardControlData.ShiftPosition = "Off";
                    sender.DisplayValue = "123#";

                    break;
                default: break;
            }
        }

        function ConvertChar() {

            angular.forEach($scope.Keyboard, function (row) {

                if (row.CharApplicable == 1) {

                    row.DisplayValue = row.Char;

                }
            })
        }

        /*India Team: Set method of keyboard service is called*/
        $scope.onEnterClick = function (sender) {
            keyboardService.set(keyboardControlData.Input.toString());

        }
        /*India Team: End changes*/

        $scope.onShiftDbClick = function (sender) {
          ConvertCase(true);
          keyboardControlData.ShiftPosition = "On-Lock";
        }


        function Revert() {
          if (keyboardControlData.ShiftPosition == "On") {
            keyboardControlData.ShiftPosition = "Off";
            ConvertCase(false);
          }
        }

        function ConvertCase(isUpper) {

          angular.forEach($scope.Keyboard, function (row) {

            if (row.CaseApplicable == 1) {

              if (isUpper) {
                row.DisplayValue = row.UpperCase;
              } else {
                row.DisplayValue = row.LowerCase;
              }

              if (row.DisplayValue == "SHIFT") {
                row.Css += " shift";
              }
              else if (row.DisplayValue == "shift") {
                if (row.Css.match(/shift_mar55/i)) {
                  row.Css = "shift_mar55";
                } else {
                  row.Css = "";
                }

              }

            }
          })
        }
      }]);

/* STC Team# End Changes# keyboard controller */
