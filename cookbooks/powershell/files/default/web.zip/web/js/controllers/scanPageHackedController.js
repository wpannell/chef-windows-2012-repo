'use strict';
(function () {
  angular.module('cytology.scanPageController', []).
      controller('ScanPageController',[
    '$scope',
    '$location',
    'inputService',
    'caseService',
    function(
        $scope,
        $location,
        inputService,
        caseService
        ) {
      caseService.reset();
      $scope.caseModel = caseService;

      inputService.subscribe().then(function(barcode) {
        return caseService.getCaseFor(barcode).then(function (caseService) {
          $scope.caseModel.case = caseService.case;
          inputService.unsubscribe();
          $location.url(caseService.page.url);
        });
      });

      $scope.getTestInput = function() {
        var barcode = $scope.test;
        return caseService.getCaseFor(barcode).then(function (caseService) {
          $scope.caseModel.case = caseService.case;
          inputService.unsubscribe();
          $location.url(caseService.page.url);
        });
      };
    }]);
})();