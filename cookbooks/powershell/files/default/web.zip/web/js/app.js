'use strict';

angular.module('cytology', [
    'cytology.caseService',
    'cytology.clockService',
    'cytology.keyboardControlData',
    'cytology.keyboardService',
    'cytology.repositoryService',
    'cytology.scannerService',
    'cytology.userService',
    'cytology.inputService',
    'cytology.footerController',
    'cytology.keyboardController',
    'cytology.loginController',
    'cytology.scannerController',
    'cytology.scanPageController',
    'cytology.slidePageController',
    'cytology.specialInstructionsController',
    'cytology.tubePageController',
    'cytology.directives',
    'cytology.filters',
    'ui.bootstrap'
  ]).config(['$routeProvider', function ($routeProvider) {
  $routeProvider.when('/login/', {
    templateUrl: 'views/loginView.html',
    controller: 'LoginController'
  });

  $routeProvider.when('/scan/', {
    templateUrl: 'views/scanView.html',
    controller: 'ScanPageController'
  });

  $routeProvider.when('/tube/', {
    templateUrl: 'views/tubeView.html',
    controller: 'TubePageController'
  });

  $routeProvider.when('/slide/', {
    templateUrl: 'views/slideView.html',
    controller: 'SlidePageController'
  });

  $routeProvider.otherwise({
    redirectTo: '/login/'
  });
}]);