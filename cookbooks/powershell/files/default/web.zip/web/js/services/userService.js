'use strict';
(function () {
  var services = angular.module('cytology.userService', []);
  services.factory('userService', ['$http', function ($http) {
    var nullUser =
        {
          id: '',
          firstname: '',
          lastname: '',
          initial: '',
          gender: '',
          DOB: '',
          isLoggedIn: false,
          hasScannedSampling: false
        },

        userService = {
          user: nullUser,

          reset: function () {
            userService.user = nullUser;
          },

          get: function (userID) {
            var future = $http.get(
                'https://api.mongolab.com/api/1/databases/vantage3/collections/users?'
                    + 'q={"id": "'
                    + userID
                    + '"}&apiKey=qKQ30Pa6XiPb3V_9id6GpSjuKjMM7AFQ'
            );

            return future.then(function (response) {
              userService.user = response.data[0];
              return userService.user;
            });
          }
        };
    return userService;
  }]);
})();