'use strict';
(function () {
  var services = angular.module('cytology.clockService', []);
  services.value('clock', {date: new Date()});
})();