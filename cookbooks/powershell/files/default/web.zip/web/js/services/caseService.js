'use strict';
(function () {
  var services = angular.module('cytology.caseService', []);
  services.factory('caseService', ['repositoryService',
    function (repositoryService) {
      repositoryService.configureCases('https://vantage3.firebaseio.com/cases');

      function findPage(_case, barcode, parent) {
        var page = emptyPage;

        function hasSamples(_case) {
          return  _case.sample.samples !== undefined;
        }

        if (hasSamples(_case)) {
          _.each(_case.sample.samples, function (container) {
            if (container.barcode === barcode) {
              if (container.sample === undefined) {
                var sample = {type: parent.sample.type, samples: [container]};
                page = {container: parent, sample: sample, url: sample.type};
              }
              else {
                page = {container: container, sample: container.sample,
                  url: container.sample.type
                };
              }
            }
            else {
              page = findPage(container, barcode, container);
            }
          });
        }

        caseService.case = _case;
        caseService.page = page;
        caseService.patient = _case.patient;
        caseService.barcode = _case.barcode;
        caseService.hasScannedSample = true;
        return page;
      }

      var
          emptyCase =
          {
            "barcode": "",
            "hasScannedSample": false,
            "patient": {
              "lastname": "",
              "gender": "",
              "firstname": "",
              "dob": "",
              "initial": ""
            },
            "sample": {
              "type": "/none",
              "samples": [
                {
                  "barcode": "",
                  "sequence": "",
                  "sample": {
                    "type": "/login",
                    "samples": []
                  }
                }
              ]
            }
          },

          emptyPage =
          {
            container: emptyCase.sample,
            sample: emptyCase.sample.samples[0],
            url: emptyCase.sample.samples[0].sample.type
          },

          emptyPatient =
          {
            dob: '',
            firstname: '',
            gender: '',
            initial: '',
            lastname: ''
          },

          caseService = {
            case: emptyCase,
            page: emptyPage,
            patient: emptyPatient,
            instructions: [],
            barcode: '',
            hasScannedSample: false,

            reset: function () {
              caseService.case = emptyCase;
              caseService.page = emptyPage;
              caseService.patient = emptyPatient;
              caseService.barcode = emptyCase.barcode;
              caseService.hasScannedSample = false;
            },

            getCaseFor: function (barcode, callback) {
              repositoryService.getCaseFor(barcode, function (_case) {
                findPage(_case, barcode);
                callback(caseService);
              });
            },

            findPage: function (_case, barcode) {
              return findPage(_case, barcode);
            },

            whenPatientChanged: function (callback) {
              repositoryService.whenPatientChanged(callback);
            }
          };
      return caseService;
    }]);
})();