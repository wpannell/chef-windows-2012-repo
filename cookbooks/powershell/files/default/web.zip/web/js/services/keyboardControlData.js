'use strict';
(function () {
  var services = angular.module('cytology.keyboardControlData', []);
  services.value('keyboardControlData', {ShiftPosition: "", Input: ""});
})();