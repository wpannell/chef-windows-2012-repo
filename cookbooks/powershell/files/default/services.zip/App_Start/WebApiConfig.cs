﻿
using System.Linq;
using System.Web.Http;
using System.Web.Http.Cors;

namespace Vantage.Service.Web.Host
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
 config.EnableCors(new EnableCorsAttribute("*","*","*"));
            config.Routes.MapHttpRoute(
                name: "DefaultApiThinPrep",
                routeTemplate: "api/{controller}/{action}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            config.Routes.MapHttpRoute(
				name: "DefaultApiSurePath",
				routeTemplate: "api/{controller}/{action}/{id}",
				defaults: new { id = RouteParameter.Optional }
			);
			
			config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            config.Routes.MapHttpRoute(
                 name: "DefaultAuthen",
                 routeTemplate: "Authen/{controller}/{action}/{UserDetail}",
                 defaults: new { controller = "OAuthVantage", action = "PostAccessToken", UserDetail = RouteParameter.Optional }
                );

            config.Routes.MapHttpRoute(
                 name: "DefaultLogin",
                 routeTemplate: "Authen/{controller}/{action}/{moduletype}/{username}/{password}/{persistent}",
                 defaults: new { controller = "OAuthVantage", action = "GetAccessToken", username = RouteParameter.Optional, password = RouteParameter.Optional, persistent = RouteParameter.Optional }
                );

            var appXmlType = config.Formatters.XmlFormatter.SupportedMediaTypes.FirstOrDefault(t => t.MediaType == "application/xml");
            config.Formatters.XmlFormatter.SupportedMediaTypes.Remove(appXmlType);
        }
    }
}