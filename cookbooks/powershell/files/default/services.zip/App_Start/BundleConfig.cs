﻿using System.Web.Optimization;

namespace Vantage.Service.Web.Host
{
    public static class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
 
        }
    }
}