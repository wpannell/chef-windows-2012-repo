﻿namespace Vantage.Service.Host
{
	using System;
	using System.Web.Http;
	using System.Web.Mvc;
	using System.Web.Optimization;
	using System.Web.Routing;

	using Castle.Windsor;
	using Castle.Windsor.Installer;

	using Vantage.Service.Host.Windsor;
	using Vantage.Service.Web.Host;

	public class Global : System.Web.HttpApplication
    {

		private readonly IWindsorContainer _windsorContainer;

		public Global()
		{
			this._windsorContainer = new WindsorContainer();
		}
        protected void Application_Start(object sender, EventArgs e)
        {
            AreaRegistration.RegisterAllAreas();

			this.InitializeWindsor();
            
            WebApiConfig.Register(GlobalConfiguration.Configuration);

            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }

		private void InitializeWindsor()
		{
			this.InstallDependencies();
			this.RegisterDependencyResolver();
		}

		private void InstallDependencies()
		{
			this._windsorContainer.Install(FromAssembly.This());
		}

		private void RegisterDependencyResolver()
		{
			GlobalConfiguration.Configuration.DependencyResolver = new WindsorDependencyResolver(this._windsorContainer.Kernel);
		}

		public override void Dispose()
		{
			this._windsorContainer.Dispose();
			base.Dispose();
		}
    }
}