﻿using System.Web.Http;
using System.Web.Http.Dispatcher;

using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Vantage.Service.Contracts;
using Vantage.Service.Web.SurePath.Services;
using Vantage.Engine.Contracts;
using Vantage.Engine.SurePath;
using Vantage.DataAccess.NHibernate.Repositories;
using Vantage.DataAccess.NHibernate;
using Vantage.DataAccess.Contracts;
 using Vantage.Service.Web.SurePath.Controller;
using Castle.Facilities.TypedFactory;

namespace Vantage.Service.Host.Windsor
{
	public class WindsorWebApiInstaller : IWindsorInstaller
	{
		public void Install(IWindsorContainer container, IConfigurationStore store)
		{
			container.AddFacility<TypedFactoryFacility>();

			container.Register(
				Component.For<IUnitOfWorkManager>().ImplementedBy<UnitOfWorkManager>(),
				Component.For<IUnitOfWork>().ImplementedBy<UnitOfWork>().LifeStyle.Singleton,
				Component.For<ISurePathService>().ImplementedBy<SurePathService>().LifeStyle.Transient,
				Component.For<ISurePathEngine>().ImplementedBy<SurePathEngine>().LifeStyle.Transient,
				Component.For<ISampleRepository>().ImplementedBy<SampleRepository>().LifeStyle.Transient,
				Component.For<ISpecimenRepository>().ImplementedBy<SpecimenRepository>().LifeStyle.Transient,
				Component.For(typeof(IRepository<>)).ImplementedBy(typeof(Repository<>)).LifeStyle.Transient
			);

			container.Register(Classes.FromAssemblyNamed("Vantage.Service.Web.SurePath").BasedOn<ApiController>().LifestyleScoped());
			//container.Register(Component.For(typeof(SurePathController)).LifestyleScoped());
			//container.Register(Classes.FromThisAssembly().BasedOn<ApiController>().LifestyleScoped());
			//Component.For<IUnitOfWorkManager>().ImplementedBy<UnitOfWorkManager>().LifeStyle.Singleton,
		}
	}
}