﻿using System.Web;
using System.Web.Mvc;

namespace Vantage.Service.Web.Host
{
    public static class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
 
        }
    }
}