﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace Vantage.Service.Web.Host
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
			config.Routes.MapHttpRoute(
				name: "DefaultApiSurePath",
				routeTemplate: "api/{controller}/{action}/{id}",
				defaults: new { id = RouteParameter.Optional }
			);
			
			config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            config.Routes.MapHttpRoute(
                 name: "DefaultAuthen",
                 routeTemplate: "Authen/{controller}/{action}/",
                 defaults: new { controller = "OAuthVantage" }
                );

            config.Routes.MapHttpRoute(
                 name: "DefaultLogin",
                 routeTemplate: "Authen/{controller}/{action}/{moduletype}/{username}/{password}/{persistent}",
                 defaults: new { controller = "OAuthVantage", action = "GetAccessToken", username = RouteParameter.Optional, password = RouteParameter.Optional, persistent = RouteParameter.Optional }
                );

            var appXmlType = config.Formatters.XmlFormatter.SupportedMediaTypes.FirstOrDefault(t => t.MediaType == "application/xml");
            config.Formatters.XmlFormatter.SupportedMediaTypes.Remove(appXmlType);
        }
    }
}